#!/usr/bin/env python
# coding=utf-8
# Contributor:
# Phus Lu <phus.lu@gmail.com>
# Wang Wei Qiang <wwqgtxx@gmail.com>

__uploaddir__ = 'python'
__proxy__= '127.0.0.1:8888'
__need_cookies__= True
__APPIDS__ = 'wwqgtxx'

def config():
   try:
       import uploader
       uploader.main()
   except KeyboardInterrupt:
       pass    

if __name__ == '__main__':
   try:
       import uploader
       uploader.main()
   except KeyboardInterrupt:
       pass