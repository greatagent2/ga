#!/usr/bin/env python
# coding=utf-8
# Contributor:
# Wang Wei Qiang <wwqgtxx@gmail.com>

import glob
__file__ = os.path.abspath('uploader.py')
if os.path.islink(__file__):
    __file__ = getattr(os, 'readlink', lambda x:x)(__file__)
os.chdir(os.path.dirname(os.path.abspath(__file__)))
os.path.join(os.path.dirname(__file__), 'config.py')
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath('./config.py'))))
sys.path += glob.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.py'))
sys.path += glob.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploader.zip'))
from config import __uploaddir__,__proxy__,__need_cookies__,__APPIDS__
import config

import sys,os
print('===============================================================')
print('GoAgent����˲������, ��ʼ�ϴ�'+__uploaddir__+'�����')
print('===============================================================')
print('')
print('����������appid, ���appid����|�Ÿ���')
if __need_cookies__== False:
    if os.path.isfile('.appcfg_cookies'):
        os.remove('.appcfg_cookies') 
os.putenv('uploaddir', __uploaddir__)
os.putenv('http_proxy', __proxy__)
os.putenv('https_proxy', __proxy__)
if sys.platform.startswith('win'):
    cmd = 'set https_proxy='+__proxy__
    os.system(cmd)
if __proxy__ != '':
    import urllib2
    proxy_handler = urllib2.ProxyHandler({"https" : 'http://'+__proxy__})
    opener = urllib2.build_opener(proxy_handler)
    urllib2.install_opener(opener)
    proxy_handler2 = urllib2.ProxyHandler({"http" : 'http://'+__proxy__})
    opener2 = urllib2.build_opener(proxy_handler2)
    urllib2.install_opener(opener2)
appids = __APPIDS__ if __APPIDS__!='' else raw_input('APPID:')
print('APPID:'+appids)
import appcfg;appcfg.main(('http://'+__proxy__),appids)
print('')
print('�ϴ��ɹ����벻Ҫ���Ǳ༭proxy.ini�����appid���ȥ��лл����������˳�����')

